package com.example.w995simulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10151B)
private val Panel = Color(0xFF202A34)
private val Orange = Color(0xFFFF6A00)
private val Silver = Color(0xFFE7EDF2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableImmersiveMode()
        setContent { W995App() }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersiveMode()
    }

    @Suppress("DEPRECATION")
    private fun enableImmersiveMode() {
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }
}

data class AppTile(val title: String, val icon: ImageVector, val subtitle: String)

@Composable
fun W995App() {
    var page by remember { mutableStateOf("Início") }
    var playing by remember { mutableStateOf(false) }
    var track by remember { mutableIntStateOf(0) }
    val tracks = listOf("Noite de Verão", "Digital Love", "Memórias 2009")
    val tiles = listOf(
        AppTile("Walkman", Icons.Default.Headphones, "Música"),
        AppTile("Mensagens", Icons.Default.Mail, "SMS demonstrativos"),
        AppTile("Contatos", Icons.Default.Contacts, "Agenda"),
        AppTile("Câmera", Icons.Default.CameraAlt, "Câmera do aparelho"),
        AppTile("Galeria", Icons.Default.PhotoLibrary, "Fotos"),
        AppTile("Rádio", Icons.Default.Radio, "Modo demonstração"),
        AppTile("Jogos", Icons.Default.SportsEsports, "Clássicos"),
        AppTile("Configurações", Icons.Default.Settings, "Personalizar")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, background = Ink, surface = Panel, onSurface = Silver
    )) {
        Column(Modifier.fillMaxSize().background(Ink)) {
            StatusBar()
            when (page) {
                "Início" -> HomeScreen(onOpen = { page = it })
                "Menu" -> MenuScreen(tiles, onOpen = { page = it })
                "Walkman" -> WalkmanScreen(
                    track = tracks[track], playing = playing,
                    onPlay = { playing = !playing },
                    onNext = { track = (track + 1) % tracks.size },
                    onBack = { page = "Menu" }
                )
                "Configurações" -> SettingsScreen(onBack = { page = "Menu" })
                else -> PlaceholderScreen(page, onBack = { page = "Menu" })
            }
            Spacer(Modifier.weight(1f))
            NavigationKeys(
                centerLabel = if (page == "Início") "MENU" else "OK",
                onLeft = { page = "Início" },
                onCenter = { if (page == "Início") page = "Menu" else if (page != "Walkman") page = "Menu" },
                onRight = { page = "Menu" }
            )
        }
    }
}

@Composable
fun StatusBar() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("WALKMAN", color = Orange, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text("4G  ▮▮▮   87%  ▰", color = Silver, fontSize = 12.sp)
    }
}

@Composable
fun ColumnScope.HomeScreen(onOpen: (String) -> Unit) {
    Box(Modifier.fillMaxWidth().weight(1f).padding(14.dp)
        .background(Brush.verticalGradient(listOf(Color(0xFF34495A), Color(0xFF101820))), RoundedCornerShape(28.dp))) {
        Column(Modifier.align(Alignment.TopStart).padding(24.dp)) {
            Text("SEXTA-FEIRA", color = Silver.copy(alpha = .75f), fontSize = 12.sp, letterSpacing = 2.sp)
            Text("15:04", color = Color.White, fontSize = 58.sp, fontWeight = FontWeight.Light)
            Text("06 NOV 2026", color = Silver, fontSize = 13.sp)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(24.dp)) {
            Text("W995", color = Orange, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("A música acompanha você.", color = Silver.copy(alpha = .8f), fontSize = 13.sp)
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(3) { Box(Modifier.size(if (it == 0) 8.dp else 6.dp)
                .background(if (it == 0) Orange else Silver.copy(alpha = .4f), RoundedCornerShape(50))) }
        }
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Atalhos", color = Silver.copy(alpha = .7f), fontSize = 12.sp)
        Text("Menu", color = Orange, fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable { onOpen("Menu") })
    }
}

@Composable
fun ColumnScope.MenuScreen(tiles: List<AppTile>, onOpen: (String) -> Unit) {
    Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
        Text("Menu principal", color = Silver, fontSize = 24.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 14.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tiles) { tile ->
                Column(Modifier.fillMaxWidth().clickable { onOpen(tile.title) }
                    .background(Panel, RoundedCornerShape(18.dp)).padding(vertical = 18.dp, horizontal = 5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(tile.icon, null, tint = Orange, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(tile.title, color = Silver, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun ColumnScope.WalkmanScreen(track: String, playing: Boolean, onPlay: () -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("WALKMAN", color = Orange, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
        Spacer(Modifier.height(26.dp))
        Box(Modifier.size(210.dp).background(Brush.linearGradient(listOf(Orange, Color(0xFF9D3100))),
            RoundedCornerShape(30.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(112.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text(track, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Artista desconhecido", color = Silver.copy(alpha = .65f), fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(26.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Silver) }
            FilledIconButton(onClick = onPlay, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Orange),
                modifier = Modifier.size(64.dp)) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null,
                    tint = Color.White, modifier = Modifier.size(34.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Silver) }
        }
        Text(if (playing) "REPRODUZINDO (DEMO)" else "PRONTO PARA REPRODUZIR",
            color = Orange, fontSize = 10.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
fun ColumnScope.SettingsScreen(onBack: () -> Unit) {
    Column(Modifier.weight(1f).padding(20.dp)) {
        Text("Configurações", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        listOf("Tema escuro clássico", "Sons de navegação", "Vibração", "Papel de parede").forEach {
            var enabled by remember { mutableStateOf(true) }
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, color = Silver, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { value -> enabled = value })
            }
            HorizontalDivider(color = Silver.copy(alpha = .12f))
        }
        TextButton(onClick = onBack) { Text("Voltar") }
    }
}

@Composable
fun ColumnScope.PlaceholderScreen(title: String, onBack: () -> Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Orange, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Área demonstrativa. Vamos implementar esta função nas próximas etapas.",
            color = Silver, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = onBack) { Text("Voltar ao menu") }
    }
}

@Composable
fun NavigationKeys(centerLabel: String, onLeft: () -> Unit, onCenter: () -> Unit, onRight: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Voltar", color = Silver, modifier = Modifier.clickable { onLeft() }.padding(12.dp))
        Box(Modifier.size(64.dp).background(Panel, RoundedCornerShape(22.dp))
            .clickable { onCenter() }, contentAlignment = Alignment.Center) {
            Text(centerLabel, color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }
        Text("Opções", color = Silver, modifier = Modifier.clickable { onRight() }.padding(12.dp))
    }
}
