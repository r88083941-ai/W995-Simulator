# W995 Simulator — Android starter

Primeiro protótipo de interface para Android, feito com Kotlin e Jetpack Compose.

## Abrir
1. Instale o Android Studio.
2. Abra a pasta `W995Simulator`.
3. Aguarde a sincronização do Gradle.
4. Conecte seu Android com depuração USB ou use um emulador.
5. Pressione Run.

## Estado deste protótipo
- Tela inicial temática W995.
- Menu em grade com atalhos.
- Tela Walkman com controles demonstrativos.
- Tela de configurações com opções visuais.
- Telas de demonstração para os demais módulos.

## Próximas etapas
- Ler arquivos de áudio autorizados pelo usuário e reproduzi-los de verdade.
- Integrar câmera e galeria usando APIs Android.
- Persistir preferências e contatos locais.
- Implementar jogos e rádio conforme disponibilidade de hardware e permissões.
- Ajustar arte, ícones, tipografia, animações e responsividade.

Este projeto é um simulador independente inspirado na linguagem visual dos celulares Walkman. Não é software oficial da Sony Ericsson e não inclui firmware, marcas gráficas ou conteúdo proprietário.

## Modo tela cheia
O protótipo agora ativa o modo imersivo do Android: as barras de status e navegação do sistema ficam ocultas enquanto a janela do simulador está em foco. Um gesto de borda ainda pode revelar temporariamente os controles do sistema, conforme o comportamento padrão do Android.
